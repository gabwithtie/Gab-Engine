#include "Mesh.h"

gbe::asset::Mesh::Mesh(std::filesystem::path path) : BaseAsset(path) {

}