#include "Material.h"

namespace gbe {
	using namespace asset;

	Material::Material(std::filesystem::path path) : BaseAsset(path)
	{
	}

	MaterialOverride::MaterialOverride() {

	}
	
	MaterialOverride::~MaterialOverride() {

	}
}