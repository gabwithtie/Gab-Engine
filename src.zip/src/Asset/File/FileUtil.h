#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <filesystem>

namespace gbe {
	namespace asset {
		class FileUtil {
			inline static void Copy(std::filesystem::path from, std::filesystem::path to) {
				std::ifstream src(from, std::ios::binary);
				std::ofstream dst(to, std::ios::binary);

				dst << src.rdbuf();
			}
		};
	}
}