#include "AssetDeserializer.h"

#include <glaze/glaze.hpp>

gbe::asset::internal::BaseAsset_base* gbe::asset::AssetDeserializer::DeserializeFile(std::string path)
{


	return nullptr;
}
