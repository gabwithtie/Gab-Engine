#pragma once

#include <list>
#include "Asset/AssetInjection/AssetReference.h"

namespace gbe {
	namespace asset {
		class AssetSocket {
		public:
			AssetSocket();
		};
	}
}