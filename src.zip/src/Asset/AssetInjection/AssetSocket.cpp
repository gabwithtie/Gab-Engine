#include "AssetSocket.h"

gbe::asset::AssetSocket::AssetSocket()
{
}
