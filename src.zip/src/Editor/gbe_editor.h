#pragma once

#include "Editor.h"
#include "Gui/InspectorData.h"