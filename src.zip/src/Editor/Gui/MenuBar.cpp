#include "MenuBar.h"

#include "Engine/gbe_engine.h"
#include "Asset/Parsing/gbeParser.h"

#include "../Editor.h"

#include "../Utility/FileDialogue.h"

void gbe::editor::MenuBar::DrawSelf()
{
	if (ImGui::BeginMenu("Edit")) {
		if (ImGui::MenuItem("Undo")) {
			Editor::Undo();
		}
		if (ImGui::MenuItem("Redo")) {
			Editor::Redo();
		}
		ImGui::EndMenu();
	}
	if (ImGui::BeginMenu("Serialization")) {
		if (ImGui::MenuItem("Load")) {
			std::string outPath = FileDialogue::GetFilePath(FileDialogue::OPEN);

			if (outPath.size() != 0) {
				SerializedObject data;
				gbe::asset::serialization::gbeParser::PopulateClass(data, outPath);
				auto newroot = gbe::Engine::CreateBlankRoot(&data);

				gbe::Engine::ChangeRoot(newroot);
			}
			else {
				Console::Log("Cancelled File Selection.");
			}
		}
		if (ImGui::MenuItem("Write")) {
			std::string outPath = FileDialogue::GetFilePath(FileDialogue::SAVE);

			if (outPath.size() != 0) {
				auto data = gbe::Engine::GetCurrentRoot()->Serialize();
				//write
				gbe::asset::serialization::gbeParser::ExportClass(data, outPath);
			}
			else {
				Console::Log("Cancelled File Selection.");
			}
		}
		ImGui::EndMenu();
	}
	if (ImGui::BeginMenu("Window")) {
		for (const auto& window : this->windows)
		{
			if (ImGui::MenuItem(window->GetWindowId().c_str())) {
				window->Set_is_open(true);
			}
		}
		ImGui::EndMenu();
	}
}

bool gbe::editor::MenuBar::ext_Begin()
{
	if (ImGui::BeginMainMenuBar()) {
		return true;
	}
	else {
		return false;
	}
}

void gbe::editor::MenuBar::ext_End()
{
	ImGui::EndMainMenuBar();
}
