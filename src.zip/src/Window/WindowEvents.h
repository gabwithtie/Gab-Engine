#pragma once

namespace gbe {
	namespace window {
		enum WindowEventType {
			RESIZE
		};
	}
}