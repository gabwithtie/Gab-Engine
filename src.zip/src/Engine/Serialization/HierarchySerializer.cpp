#include "HierarchySerializer.h"

gbe::HierarchySerializer::HierarchySerializer(Object* _hierarchy_root)
{
	this->hierarchy_root = _hierarchy_root;
}

std::string gbe::HierarchySerializer::Serialize(std::string path)
{


	return std::string();
}

gbe::Object* gbe::HierarchySerializer::DeserializeAndParent(std::string path)
{
	return nullptr;
}
