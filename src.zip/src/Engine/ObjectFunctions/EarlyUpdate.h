#pragma once

namespace gbe {
	class EarlyUpdate{
	public:
		virtual void InvokeEarlyUpdate() = 0;
	};
}