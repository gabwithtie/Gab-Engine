#pragma once

#include "Asset/gbe_asset.h"
#include "Math/gbe_math.h"

#include "TextureLoader.h"

#include <optional>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>

namespace gbe {
	namespace gfx {
		struct ShaderStageMeta {
			struct TextureMeta {
				std::string name;
				std::string type;
				unsigned int set;
				unsigned int binding;
				std::vector<int> array;
			};
			struct UboType {
				struct UboTypeMember {
					std::string name;
					std::string type;
					unsigned int offset;
				};

				std::string name;
				std::vector<UboTypeMember> members;
			};
			struct UboMeta {
				std::string name;
				std::string type;
				unsigned int block_size;
				unsigned int set;
				unsigned int binding;
				std::vector<int> array;
			};
			std::unordered_map<std::string, UboType> types;
			std::vector<TextureMeta> textures;
			std::vector<UboMeta> ubos;
			std::vector<UboMeta> push_constants;
		};

		struct ShaderData {
			struct ShaderBlock {
				std::string name = "";
				size_t block_size = 0;
				size_t block_size_aligned = 0;
				unsigned int set = 0;
				unsigned int binding = 0;
				unsigned int array_size = 1;
			};

			struct ShaderField {
				std::string name = "";
				std::string block = "";
				unsigned int set = 0;
				unsigned int binding = 0;
				asset::Shader::UniformFieldType type;
				unsigned int array_size = 1;
				size_t offset = 0;
				size_t size = 0;
			};

			std::map<unsigned int, std::vector<VkDescriptorSetLayoutBinding>> binding_sets;
			std::map<unsigned int, VkDescriptorSetLayout> descriptorSetLayouts;
			std::vector<ShaderBlock> uniformblocks;
			std::vector<ShaderField> uniformfields;
			VkPipelineLayout pipelineLayout;
			VkPipeline pipeline;
			asset::Shader* asset;

			bool FindUniformField(std::string id, ShaderField& out_field, ShaderBlock& out_block);
			bool FindUniformBlock(std::string id, ShaderBlock& out_block);
		};

		class ShaderLoader : public asset::AssetLoader<asset::Shader, asset::data::ShaderImportData, asset::data::ShaderLoadData, ShaderData> {
		private:
			VkShaderModule TryCompileShader(const std::vector<char>& code);
		protected:
			ShaderData LoadAsset_(asset::Shader* asset, const asset::data::ShaderImportData& importdata, asset::data::ShaderLoadData* data) override;
			void UnLoadAsset_(asset::Shader* asset, const asset::data::ShaderImportData& importdata, asset::data::ShaderLoadData* data) override;
		public:
		};
	}
}