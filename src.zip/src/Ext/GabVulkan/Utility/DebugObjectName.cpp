#include "DebugObjectName.h"

PFN_vkSetDebugUtilsObjectNameEXT gbe::vulkan::DebugObjectName::PFN_SETDEBUGUTILSOBJECTNAME = nullptr;