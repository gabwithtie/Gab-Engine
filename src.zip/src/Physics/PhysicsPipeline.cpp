#include "PhysicsPipeline.h"

gbe::physics::PhysicsWorld* gbe::physics::PhysicsPipeline::current_world = nullptr;